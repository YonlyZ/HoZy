const { Client, GatewayIntentBits, Partials, EmbedBuilder } = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel] // Necessário pra ler DMs
});

client.once("ready", () => {
  console.log(`🤖 Bot conectado como ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  // Ignorar bots
  if (message.author.bot) return;

  // Verifica se o bot foi mencionado
  const isMentioned = message.mentions.has(client.user);

  if (isMentioned) {
    const embed = new EmbedBuilder()
      .setColor("#FF7F00")
      .setTitle("🔔 Chamado recebido!")
      .setDescription(`Olá, ${message.author.toString()}!\nComo posso ajudar?`)
      .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
      .setFooter({
        text: `Usuário: ${message.author.tag}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    try {
      await message.reply({ embeds: [embed] });
      console.log(`✅ Respondi ${message.author.tag} no canal ${message.channel.id}`);
    } catch (error) {
      console.error(`❌ Erro ao responder ${message.author.tag}:`, error);
    }
  }
});

// LOGIN — troque pelo seu token do bot
client.login("MTM5MDA1MzEwNzg0NDc4MDAzMg.G8rjFL.LWxC_wxrAxLeNCaJk8RZvN_2nQv2sLsF2QxR5Q");